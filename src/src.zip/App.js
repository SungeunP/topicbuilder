import React, { Component, Fragment } from 'react';
import SideList from './SideList';
import Middle from './Middle';
import Preview from './Preview'; 

class App extends Component {
  render() {
    return (
      <Fragment>
        <div className="contents col-sm-12">
          <div className="row" > {/* style="position: relative; z-index: 100;" */}
            <SideList />
            <Middle />
            <Preview />
          </div>
        </div>
      </Fragment>
    );
  }
}

export default App;
