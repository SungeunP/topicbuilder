import React, { Component } from 'react';
import TopicBar from './TopicBar';
import TopicInfo from './TopicInfo';
import TopicMain from './TopicMain';

class Middle extends Component {
  render() {
    return (
      <div class="col-sm-7 question-contents">
        <TopicBar />
        <TopicInfo />
        <TopicMain />
      </div>
    );
  }
}

export default Middle;
