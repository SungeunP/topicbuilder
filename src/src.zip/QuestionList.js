import React, { Component } from 'react';
import './QuestionList.css';


class QuestionList extends Component {

    static defaultProps = {
        QuestionComp_list : [
          {name : "질문이 없습니다."}
        ]
      }

    render() {
        return (
            <div className="question-list">
                <p className="list-header">
                    <strong>질문 목록</strong>
                    <span><button type="button" className="searchvar-btn"><i className="fas fa-search"></i></button></span>
                    <span><button type="button" className="list-btn"><i className="fas fa-caret-down"></i></button></span>
                    <span className="hidden previous-close-btn"><button type="button"><i className="fas fa-caret-down"></i></button></span>
                </p>
                <ul className="list-contents">
                    <li className="search"><input type="text" placeholder="검색어를 입력해 주십시오" /><input type="submit" value="검색" className="btn-custom btn-custom-black" /></li>
                    {
                        this._RenderQuestionList
                    } 
                </ul>
            </div>
        )
    }

    /* Array Component 랜더링 */
    _RenderQuestionList = this.props.QuestionComp_list.map(Question_comp => {
        return (
            <Question 
                name={Question_comp.name}/>
        );
    });

}

/* Array Component rendering roop function */
function Question ({name}) {
    return (
    <li><a href="">{name}<button class="array-config-btn"><i class="fas fa-cog"></i></button></a></li>
    );
}



export default QuestionList;