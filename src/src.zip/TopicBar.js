import React, { Component } from 'react';

class TopicBar extends Component {
  render() {
    return (
      <div className="btn-line">
          <button className="btn-custom btn-custom-black add-question-btn">대화 추가</button>
          <button className="btn-custom btn-custom-success">임시 저장</button>
          <button className="btn-custom btn-custom-default">임시 저장 불러오기</button>
          <button className="btn-custom btn-custom-success">생성</button>
          <button className="btn-custom btn-custom-danger">나가기</button>
      </div>
    );
  }
}

export default TopicBar;