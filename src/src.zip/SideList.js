import React, { Component , Fragment } from 'react';
import QuestionList from './QuestionList';
import ArrayList from './ArrayList';

class SideList extends Component {
  render() {
    return (
      <div class="col-sm-2">
        <QuestionList />
        <ArrayList />
      </div>
    );
  }
}

export default SideList;
